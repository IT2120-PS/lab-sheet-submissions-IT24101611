setwd("C:\\Users\\User\\OneDrive\\Desktop\\Lab06")


# Exercise 1

n <- 50      # number of students
p <- 0.85    # probability of passing

# i. Distribution of X
# X ~ Binomial(n, p)

# ii. Probability that at least 47 students passed
pbinom(46, size = n, prob = p, lower.tail = FALSE)


# Exercise 2

lambda <- 12   # average calls per hour

# i. Random variable X = number of calls in one hour
# ii. Distribution of X ~ Poisson(lambda)

# iii. Probability that exactly 15 calls are received
dpois(15, lambda = lambda)

