setwd("C:\\Users\\User\\OneDrive\\Desktop\\Lab07")


# 1. Uniform Distribution
# Train arrives uniformly between 0 and 40 minutes (after 8:00 a.m.)
a <- 0
b <- 40
# Probability that train arrives between 10 and 25 minutes
p1 <- (25 - 10) / (b - a)
p1


# 2. Exponential Distribution
# Time to complete update ~ Exp(lambda = 1/3)
lambda <- 1/3
# Probability that update takes at most 2 hours
p2 <- pexp(2, rate = lambda)
p2


# 3. Normal Distribution (IQ scores)
mean_iq <- 100
sd_iq <- 15

# i. Probability IQ > 130
p3_i <- 1 - pnorm(130, mean = mean_iq, sd = sd_iq)
p3_i

# ii. IQ score at 95th percentile
p3_ii <- qnorm(0.95, mean = mean_iq, sd = sd_iq)
p3_ii
